#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from rclpy.clock import Clock, ClockType
from sensor_msgs.msg import JointState
from std_msgs.msg import Header
from geometry_msgs.msg import TransformStamped, PoseStamped, PoseWithCovarianceStamped
from visualization_msgs.msg import Marker, MarkerArray
from tf2_ros import TransformBroadcaster

import numpy as np
import math
import httpx
import mgrs
from typing import Optional

from kinematic_model import TractorTrailerModel

class AGVPoseDisplayNode(Node):
    def __init__(self):
        super().__init__('agv_pose_display_node')
        
        # ROS Parameters
        self.declare_parameter('namespace', 'agv1')
        self.declare_parameter('dt', 0.1)
        self.declare_parameter('map_elevation', 0.0)

        # Vehicle Dimensions
        self.declare_parameter('wheel_base', 1.400)
        self.declare_parameter('wheel_radius', 0.3)
        self.declare_parameter('wheel_width', 0.3)
        self.declare_parameter('wheel_tread', 1.0)
        self.declare_parameter('max_steer_angle', 0.70)
        self.declare_parameter('max_drawbar_angle', 0.70)
        self.declare_parameter('front_overhang', 0.85)
        self.declare_parameter('rear_overhang', 0.70)
        self.declare_parameter('left_overhang', 0.75)
        self.declare_parameter('right_overhang', 0.75)
        self.declare_parameter('hitch_length', 0.70)
        
        self.declare_parameter('trailer_wheel_radius', 0.33)
        self.declare_parameter('drawbar_track_width', 1.0)
        self.declare_parameter('drawbar_joint_length', 1.53)
        self.declare_parameter('drawbar_left_overhang', 0.50)
        self.declare_parameter('drawbar_right_overhang', 0.50)
        self.declare_parameter('drawbar_top_height', 0.70)
        
        self.declare_parameter('trailer_track_width', 1.0)
        self.declare_parameter('trailer_joint_length', 1.98)
        self.declare_parameter('trailer_left_overhang', 0.75)
        self.declare_parameter('trailer_right_overhang', 0.75)
        self.declare_parameter('trailer_hitch_length', 0.515)
        self.declare_parameter('trailer_thickness', 0.20)
        self.declare_parameter('hitch_height', 0.40)

        # Color Parameters (Kept for fallback or line markers)
        self.declare_parameter('color_tractor', [1.0, 0.27, 0.0, 0.5])
        self.declare_parameter('color_trailer', [0.0, 0.0, 1.0, 0.5])
        self.declare_parameter('color_wheel', [1.0, 1.0, 1.0, 1.0])
        self.declare_parameter('color_drawbar', [0.8, 0.9, 1.0, 1.0])

        # API & Authentication Parameters
        self.declare_parameter('server_adds', '192.168.2.178')
        self.declare_parameter('server_port', 5000)
        self.declare_parameter('auth_endpoint', '/authentication/login')
        self.declare_parameter('position_endpoint', '/vehicle/vehicles')
        self.declare_parameter('username', 'admin3@minebea.co.th')
        self.declare_parameter('password', 'admin')
        self.declare_parameter('vehicle_name', 'AGV1')
        self.declare_parameter('state_filter', 'ALL')
        self.declare_parameter('poll_rate_hz', 2.0)

        # Get Parameters
        self.ns = self.get_parameter('namespace').value
        self.dt = self.get_parameter('dt').value
        self.map_elevation = self.get_parameter('map_elevation').value
        self.L0 = self.get_parameter('wheel_base').value
        self.wheel_diam = self.get_parameter('wheel_radius').value * 2.0
        self.W = self.get_parameter('wheel_tread').value
        self.trailer_wheel_radius = self.get_parameter('trailer_wheel_radius').value
        self.db_tw = self.get_parameter('drawbar_track_width').value
        self.tl_tw = self.get_parameter('trailer_track_width').value

        self.color_tractor = self.get_parameter('color_tractor').value
        self.color_trailer = self.get_parameter('color_trailer').value
        self.color_wheel = self.get_parameter('color_wheel').value
        self.color_drawbar = self.get_parameter('color_drawbar').value

        # Trailer Structure Setup
        db_len = self.get_parameter('drawbar_joint_length').value
        tr_len = self.get_parameter('trailer_joint_length').value
        hitch_len = self.get_parameter('hitch_length').value
        tr_hitch_len = self.get_parameter('trailer_hitch_length').value
        
        num_trailers = 4
        l_bars = [db_len] * num_trailers
        l_trls = [tr_len] * num_trailers
        dh_prevs = [hitch_len] + [tr_hitch_len] * (num_trailers - 1)

        self.trailers = []
        for i in range(num_trailers):
            self.trailers.append({
                'L_bar': l_bars[i],
                'L_trl': l_trls[i],
                'dh_prev': dh_prevs[i]
            })

        max_steer_angle = self.get_parameter('max_steer_angle').value
        max_drawbar_angle = self.get_parameter('max_drawbar_angle').value

        # Kinematics Model
        self.model = TractorTrailerModel(
            self.L0, 
            self.trailers, 
            dt=self.dt, 
            max_steering_angle=max_steer_angle, 
            max_drawbar_angle=max_drawbar_angle
        )
        
        self.state = np.zeros(3 + 2 * len(self.trailers))
        self.wheel_phi = np.zeros(2 + len(self.trailers))
        self.v0 = 0.0
        self.delta = 0.0
        
        self.last_api_pos = None
        self.last_api_time = None
        self.marker_id_counter = 0

        # Setup HTTP Client
        self.server_adds = self.get_parameter('server_adds').value
        self.server_port = self.get_parameter('server_port').value
        self.auth_endpoint = self.get_parameter('auth_endpoint').value
        self.position_endpoint = self.get_parameter('position_endpoint').value
        self.username = self.get_parameter('username').value
        self.password = self.get_parameter('password').value
        self.vehicle_name = self.get_parameter('vehicle_name').value
        self.state_filter = self.get_parameter('state_filter').value
        
        self.login_url = f"http://{self.server_adds}:{self.server_port}{self.auth_endpoint}"
        self.position_url = f"http://{self.server_adds}:{self.server_port}{self.position_endpoint}"
        
        self.http_client = httpx.Client(timeout=2.0)
        self.auth_token = None
        
        # Initial Authentication
        self.login()

        # Publishers & Broadcasters
        self.pub_joints = self.create_publisher(JointState, f'/{self.ns}/joint_states', 10)
        self.pub_markers = self.create_publisher(MarkerArray, f'/{self.ns}/vehicle_markers', 10)
        self.pub_agv_pose = self.create_publisher(PoseStamped, f'/{self.ns}/pose', 10)
        self.tf_broadcaster = TransformBroadcaster(self)

        # Manual Initial Pose Subscriber
        self.sub_initial = self.create_subscription(
            PoseWithCovarianceStamped, f'/{self.ns}/initialpose', self.initial_pose_callback, 10
        )

        # Timers
        poll_rate = self.get_parameter('poll_rate_hz').value
        self.api_timer = self.create_timer(1.0 / poll_rate, self.get_api_pose)

        system_clock = Clock(clock_type=ClockType.SYSTEM_TIME)
        self.timer = self.create_timer(self.dt, self.update, clock=system_clock)

        self.get_logger().info(f'AGV Pose Display Node initialized for {self.vehicle_name} (Topic NS: {self.ns})')

    def login(self) -> bool:
        """Authenticate with username and password to retrieve JWT access token."""
        headers = {
            'accept': 'application/json',
            'Content-Type': 'application/x-www-form-urlencoded'
        }
        form_data = {
            'grant_type': 'password',
            'username': self.username,
            'password': self.password,
            'scope': '',
            'client_id': 'string',
            'client_secret': 'string'
        }

        try:
            response = self.http_client.post(self.login_url, headers=headers, data=form_data)
            if response.status_code == 200:
                data = response.json()
                self.auth_token = data.get('access_token') or data.get('payload', {}).get('access_token')
                if self.auth_token:
                    self.get_logger().info(f'Successfully logged in as {self.username}. Token acquired.')
                    return True
                else:
                    self.get_logger().error('Login succeeded but no access_token found in response body.')
                    return False
            else:
                self.get_logger().error(f'Login failed: HTTP {response.status_code} - {response.text}', throttle_duration_sec=3.0)
                return False
        except Exception as exc:
            self.get_logger().error(f'Login connection error: {exc}', throttle_duration_sec=3.0)
            return False

    def euler_to_quaternion(self, roll: float, pitch: float, yaw: float):
        """Convert Roll-Pitch-Yaw angles to quaternion list."""
        qx = math.sin(roll/2) * math.cos(pitch/2) * math.cos(yaw/2) - math.cos(roll/2) * math.sin(pitch/2) * math.sin(yaw/2)
        qy = math.cos(roll/2) * math.sin(pitch/2) * math.cos(yaw/2) + math.sin(roll/2) * math.cos(pitch/2) * math.sin(yaw/2)
        qz = math.cos(roll/2) * math.cos(pitch/2) * math.sin(yaw/2) - math.sin(roll/2) * math.sin(pitch/2) * math.cos(yaw/2)
        qw = math.cos(roll/2) * math.cos(pitch/2) * math.cos(yaw/2) + math.sin(roll/2) * math.sin(pitch/2) * math.sin(yaw/2)
        return [qx, qy, qz, qw]

    def to_map_coordinate(self, cx: float, cy: float, px: float, py: float, theta: float):
        """Transform local CAD coordinate (cx, cy) to global map coordinate."""
        mx = px + cx * math.cos(theta) - cy * math.sin(theta)
        my = py + cx * math.sin(theta) + cy * math.cos(theta)
        return mx, my

    def wheel_mesh_position(self, hub_x, hub_y, yaw, spin, z, center):
        """Place a CAD wheel so its measured mesh center remains at the hub."""
        cx, cy, cz = center  # Mesh center after the fixed 90-degree roll and 0.01 scale.
        spun_x = math.cos(spin) * cx + math.sin(spin) * cz
        spun_z = -math.sin(spin) * cx + math.cos(spin) * cz
        c, s = math.cos(yaw), math.sin(yaw)
        return (hub_x - c * spun_x + s * cy,
                hub_y - s * spun_x - c * cy,
                z + cz - spun_z)

    def broadcast_relative_tf(self, parent_frame, child_frame, parent_xy, child_xy,
                              parent_yaw, child_yaw, stamp):
        """Publish a hitch link in its parent's moving coordinate frame."""
        dx = float(child_xy[0] - parent_xy[0])
        dy = float(child_xy[1] - parent_xy[1])
        c, s = math.cos(parent_yaw), math.sin(parent_yaw)
        t = TransformStamped()
        t.header.stamp = stamp
        t.header.frame_id = parent_frame
        t.child_frame_id = child_frame
        t.transform.translation.x = c * dx + s * dy
        t.transform.translation.y = -s * dx + c * dy
        t.transform.rotation.z = math.sin((child_yaw - parent_yaw) / 2.0)
        t.transform.rotation.w = math.cos((child_yaw - parent_yaw) / 2.0)
        self.tf_broadcaster.sendTransform(t)

    def broadcast_hitch_tf(self, roll: float, pitch: float, yaw: float, child_frame: str, parent_frame: str, tf_timestamp):
        """Broadcast a TF transform for hitch connections with namespace prefix."""
        t_h = TransformStamped()
        t_h.header.stamp = tf_timestamp
        t_h.header.frame_id = parent_frame
        t_h.child_frame_id = child_frame
        t_h.transform.translation.x = 0.0
        t_h.transform.translation.y = 0.0
        t_h.transform.translation.z = 0.0
        q_h = self.euler_to_quaternion(roll, pitch, yaw)
        t_h.transform.rotation.x = q_h[0]
        t_h.transform.rotation.y = q_h[1]
        t_h.transform.rotation.z = q_h[2]
        t_h.transform.rotation.w = q_h[3]
        self.tf_broadcaster.sendTransform(t_h)

    def create_mesh_marker(self, x: float, y: float, z: float, roll: float, pitch: float, yaw: float, mesh_path: str, timestamp, frame_id='map'):
        """Construct and return a visualization Marker in map frame."""
        m = Marker()
        m.header.frame_id = frame_id
        m.header.stamp = timestamp
        m.ns = "meshes"
        m.id = self.marker_id_counter
        self.marker_id_counter += 1
        m.type = Marker.MESH_RESOURCE
        m.action = Marker.ADD
        m.pose.position.x = float(x)
        m.pose.position.y = float(y)
        m.pose.position.z = float(z)
        q_m = self.euler_to_quaternion(roll, pitch, yaw)
        m.pose.orientation.x = q_m[0]
        m.pose.orientation.y = q_m[1]
        m.pose.orientation.z = q_m[2]
        m.pose.orientation.w = q_m[3]
        m.scale.x = 0.01
        m.scale.y = 0.01
        m.scale.z = 0.01
        m.color.r = 1.0
        m.color.g = 1.0
        m.color.b = 1.0
        m.color.a = 1.0
        m.mesh_resource = mesh_path
        m.mesh_use_embedded_materials = True
        return m

    def initial_pose_callback(self, msg):
        q = msg.pose.pose.orientation
        siny_cosp = 2 * (q.w * q.z + q.x * q.y)
        cosy_cosp = 1 - 2 * (q.y * q.y + q.z * q.z)
        theta0 = math.atan2(siny_cosp, cosy_cosp)
        
        self.state[0] = msg.pose.pose.position.x
        self.state[1] = msg.pose.pose.position.y
        self.state[2] = theta0
        for i in range(len(self.trailers)):
            self.state[3 + 2*i] = theta0
            self.state[3 + 2*i + 1] = theta0
        
        self.last_api_pos = None
        self.last_api_time = None

    def get_api_pose(self):
        """Fetches latest pose from server. Automatically re-logs in if unauthenticated."""
        if not self.auth_token:
            self.login()
            return

        headers = {
            'accept': 'application/json',
            'Authorization': f'Bearer {self.auth_token}'
        }
        params = {
            'vehicle_name': self.vehicle_name,
            'state': self.state_filter
        }

        try:
            response = self.http_client.get(self.position_url, headers=headers, params=params)

            # Auto re-login if token expired or invalid
            if response.status_code == 401:
                self.get_logger().warn('Token expired (HTTP 401). Refreshing token...')
                if self.login():
                    headers['Authorization'] = f'Bearer {self.auth_token}'
                    response = self.http_client.get(self.position_url, headers=headers, params=params)
                else:
                    return

            if response.status_code != 200:
                return

            res_json = response.json()
            payload_list = res_json.get('payload', [])
            if not payload_list:
                return

            vehicle_data = payload_list[0]
            coord_raw = vehicle_data.get('coordinate', None)
            if coord_raw is None:
                return

            if isinstance(coord_raw, list):
                parts = [float(val) for val in coord_raw]
            elif isinstance(coord_raw, str):
                parts = [float(val.strip()) for val in coord_raw.split(',') if val.strip()]
            else:
                return

            if len(parts) < 3:
                return

            lat = parts[0]
            lon = parts[1]
            new_yaw = parts[2]
            try:
                mgrs_coord = self.convert_latlon_to_mgrs(lat, lon, precision=5)
                easting_str = mgrs_coord[-10:-5]
                northing_str = mgrs_coord[-5:]
                
                new_x = float(easting_str)
                new_y = float(northing_str)
            except ValueError:
                self.get_logger().error(f"Failed to parse MGRS coordinates from: {mgrs_coord}")
                return
            now_sec = self.get_clock().now().nanoseconds * 1e-9

            # First sample initialization
            if self.last_api_pos is None or self.last_api_time is None:
                self.state[0] = new_x
                self.state[1] = new_y
                self.state[2] = new_yaw
                for i in range(len(self.trailers)):
                    self.state[3 + 2*i] = new_yaw
                    self.state[3 + 2*i + 1] = new_yaw
                self.last_api_pos = (new_x, new_y, new_yaw)
                self.last_api_time = now_sec
                return

            dt = now_sec - self.last_api_time
            if dt > 0.001:
                dx = new_x - self.last_api_pos[0]
                dy = new_y - self.last_api_pos[1]
                dist = math.hypot(dx, dy)
                heading_dir = math.atan2(dy, dx)

                angle_diff = heading_dir - self.state[2]
                while angle_diff > math.pi: angle_diff -= 2*math.pi
                while angle_diff < -math.pi: angle_diff += 2*math.pi

                if abs(angle_diff) > math.pi / 2.0:
                    self.v0 = -dist / dt
                else:
                    self.v0 = dist / dt

                d_yaw = new_yaw - self.last_api_pos[2]
                while d_yaw > math.pi: d_yaw -= 2*math.pi
                while d_yaw < -math.pi: d_yaw += 2*math.pi
                omega = d_yaw / dt

                if abs(self.v0) > 0.05:
                    self.delta = math.atan2(omega * self.L0, self.v0)
                else:
                    self.delta = 0.0

                # Only re-align the trailers after a genuine position jump.
                # A 1 m GPS step or a normal turn must retain articulation.
                if dist > max(5.0, 2.0 * self.model.max_velocity * dt):
                    for i in range(len(self.trailers)):
                        self.state[3 + 2*i] = new_yaw
                        self.state[3 + 2*i + 1] = new_yaw

                self.state[0] = new_x
                self.state[1] = new_y
                self.state[2] = new_yaw

                self.last_api_pos = (new_x, new_y, new_yaw)
                self.last_api_time = now_sec

            # Publish PoseStamped
            p_msg = PoseStamped()
            p_msg.header.stamp = self.get_clock().now().to_msg()
            p_msg.header.frame_id = 'map'
            p_msg.pose.position.x = new_x
            p_msg.pose.position.y = new_y
            p_msg.pose.position.z = float(self.map_elevation)
            q = self.euler_to_quaternion(0.0, 0.0, new_yaw)
            p_msg.pose.orientation.x = q[0]
            p_msg.pose.orientation.y = q[1]
            p_msg.pose.orientation.z = q[2]
            p_msg.pose.orientation.w = q[3]
            self.pub_agv_pose.publish(p_msg)

        except Exception as exc:
            self.get_logger().error(f'API Polling error: {exc}', throttle_duration_sec=2.0)

    def update(self):
        """
        Full Standalone Update Loop using 2-Step Transform for Mesh Pivot Alignment.
        """
        # 1. Update Tractor-Trailer Kinematic State
        tractor_state_odom = self.state[0:3].copy()
        new_state = self.model.update(self.state, self.v0, self.delta)
        self.state = new_state
        self.state[0:3] = tractor_state_odom

        # Extract CAD reference coordinates from kinematic model
        coords = self.model.get_coordinates(self.state)
        
        # Unified system clock timestamp
        sys_clock = Clock(clock_type=ClockType.SYSTEM_TIME)
        current_stamp = sys_clock.now().to_msg()

        # 2. Broadcast Global TF (Used by RViz Camera Target Frame)
        t = TransformStamped()
        t.header.stamp = current_stamp
        t.header.frame_id = 'map'
        t.child_frame_id = f'{self.ns}_base_link'
        t.transform.translation.x = float(self.state[0])
        t.transform.translation.y = float(self.state[1])
        t.transform.translation.z = float(self.map_elevation)
        q = self.euler_to_quaternion(0.0, 0.0, self.state[2])
        t.transform.rotation.x = q[0]
        t.transform.rotation.y = q[1]
        t.transform.rotation.z = q[2]
        t.transform.rotation.w = q[3]
        self.tf_broadcaster.sendTransform(t)

        # 3. Wheel Rotation Integration
        v_tr_rear = self.v0
        self.wheel_phi[0] += (v_tr_rear / (self.wheel_diam / 2.0)) * self.dt
        v_tr_front = self.v0 / math.cos(self.delta) if math.cos(self.delta) != 0 else self.v0
        self.wheel_phi[1] += (v_tr_front / (self.wheel_diam / 2.0)) * self.dt
        for i in range(len(self.trailers)):
            self.wheel_phi[2 + i] += (self.v0 / (self.wheel_diam / 2.0)) * self.dt

        # 4. Generate Visual 3D Meshes via MarkerArray
        marker_array = MarkerArray()
        self.marker_id_counter = 0

        # CAD Origin Offsets (x, y, z)
        tr_cad = (0.850064, -0.001778, 0.0)
        db_cad = (3.08664, -0.001778, 0.0)
        tl_cad = (5.08157, -0.001778, 0.0)
        mesh_rpy = (1.570796, 0.0, 0.0)
        # Centers measured from the OBJ vertex bounds after scale and fixed roll.
        wheel_centers = {
            'fl': (0.550311, 0.498933, 0.270015),
            'fr': (0.550311, -0.495179, 0.270015),
            'rl': (-0.850064, 0.497945, 0.331764),
            'rr': (-0.850064, -0.494389, 0.331764),
            'dl': (-3.086639, 0.497945, 0.331764),
            'dr': (-3.086639, -0.494389, 0.331764),
            'tl': (-5.081575, 0.497945, 0.331764),
            'tr': (-5.081575, -0.494389, 0.331764),
        }
        
        map_z = float(self.map_elevation)
        p0 = coords[0]
        theta0 = self.state[2]

        # --- Tractor Chassis ---
        tr_x, tr_y = self.to_map_coordinate(tr_cad[0], tr_cad[1], p0[0], p0[1], theta0)
        marker_array.markers.append(self.create_mesh_marker(
            tr_x, tr_y, map_z, mesh_rpy[0], mesh_rpy[1], theta0,
            'package://tractor_description/mesh/TowTractor_Chassis.obj', current_stamp
        ))

        # --- Tractor Wheels ---
        wb = self.L0
        tw = self.W
        steer = self.delta

        # Front-Left Wheel
        fl_x, fl_y = self.to_map_coordinate(wb, tw / 2.0, p0[0], p0[1], theta0)
        fl_mx, fl_my, fl_mz = self.wheel_mesh_position(fl_x, fl_y, theta0 + steer, self.wheel_phi[1], map_z, wheel_centers['fl'])
        marker_array.markers.append(self.create_mesh_marker(
            fl_mx, fl_my, fl_mz, mesh_rpy[0], mesh_rpy[1] + self.wheel_phi[1], theta0 + steer,
            'package://tractor_description/mesh/TowTractor_FL_Wheel.obj', current_stamp
        ))

        # Front-Right Wheel
        fr_x, fr_y = self.to_map_coordinate(wb, -tw / 2.0, p0[0], p0[1], theta0)
        fr_mx, fr_my, fr_mz = self.wheel_mesh_position(fr_x, fr_y, theta0 + steer, self.wheel_phi[1], map_z, wheel_centers['fr'])
        marker_array.markers.append(self.create_mesh_marker(
            fr_mx, fr_my, fr_mz, mesh_rpy[0], mesh_rpy[1] + self.wheel_phi[1], theta0 + steer,
            'package://tractor_description/mesh/TowTractor_FR_Wheel.obj', current_stamp
        ))

        # Rear-Left Wheel
        rl_x, rl_y = self.to_map_coordinate(0.0, tw / 2.0, p0[0], p0[1], theta0)
        rl_mx, rl_my, rl_mz = self.wheel_mesh_position(rl_x, rl_y, theta0, self.wheel_phi[0], map_z, wheel_centers['rl'])
        marker_array.markers.append(self.create_mesh_marker(
            rl_mx, rl_my, rl_mz, mesh_rpy[0], mesh_rpy[1] + self.wheel_phi[0], theta0,
            'package://tractor_description/mesh/TowTractor_RL_Wheel.obj', current_stamp
        ))

        # Rear-Right Wheel
        rr_x, rr_y = self.to_map_coordinate(0.0, -tw / 2.0, p0[0], p0[1], theta0)
        rr_mx, rr_my, rr_mz = self.wheel_mesh_position(rr_x, rr_y, theta0, self.wheel_phi[0], map_z, wheel_centers['rr'])
        marker_array.markers.append(self.create_mesh_marker(
            rr_mx, rr_my, rr_mz, mesh_rpy[0], mesh_rpy[1] + self.wheel_phi[0], theta0,
            'package://tractor_description/mesh/TowTractor_RR_Wheel.obj', current_stamp
        ))

        # --- Trailers and Drawbars (1 to 4) ---
        for k in range(len(self.trailers)):
            p_dolly = coords[3 + 3 * k]
            p_axle = coords[4 + 3 * k]
            theta_drawbar = self.state[3 + 2 * k]
            theta_trailer = self.state[3 + 2 * k + 1]

            parent_xy = coords[0] if k == 0 else coords[4 + 3 * (k - 1)]
            parent_yaw = self.state[2] if k == 0 else self.state[3 + 2 * (k - 1) + 1]
            parent_frame = f'{self.ns}_base_link' if k == 0 else f'{self.ns}_trailer_{k}_link'
            drawbar_frame = f'{self.ns}_drawbar_{k + 1}_link'
            trailer_frame = f'{self.ns}_trailer_{k + 1}_link'
            self.broadcast_relative_tf(parent_frame, drawbar_frame, parent_xy, p_dolly,
                                       parent_yaw, theta_drawbar, current_stamp)
            self.broadcast_relative_tf(drawbar_frame, trailer_frame, p_dolly, p_axle,
                                       theta_drawbar, theta_trailer, current_stamp)

            # Drawbar Body
            db_x, db_y = self.to_map_coordinate(db_cad[0], db_cad[1], p_dolly[0], p_dolly[1], theta_drawbar)
            marker_array.markers.append(self.create_mesh_marker(
                db_x, db_y, map_z, mesh_rpy[0], mesh_rpy[1], theta_drawbar,
                'package://tractor_description/mesh/Drawbar.obj', current_stamp
            ))

            # Drawbar Left Wheel
            dl_x, dl_y = self.to_map_coordinate(0.0, self.db_tw / 2.0, p_dolly[0], p_dolly[1], theta_drawbar)
            dl_mx, dl_my, dl_mz = self.wheel_mesh_position(dl_x, dl_y, theta_drawbar, self.wheel_phi[2 + k], map_z, wheel_centers['dl'])
            marker_array.markers.append(self.create_mesh_marker(
                dl_mx, dl_my, dl_mz, mesh_rpy[0], mesh_rpy[1] + self.wheel_phi[2 + k], theta_drawbar,
                'package://tractor_description/mesh/DL_Wheel.obj', current_stamp
            ))

            # Drawbar Right Wheel
            dr_x, dr_y = self.to_map_coordinate(0.0, -self.db_tw / 2.0, p_dolly[0], p_dolly[1], theta_drawbar)
            dr_mx, dr_my, dr_mz = self.wheel_mesh_position(dr_x, dr_y, theta_drawbar, self.wheel_phi[2 + k], map_z, wheel_centers['dr'])
            marker_array.markers.append(self.create_mesh_marker(
                dr_mx, dr_my, dr_mz, mesh_rpy[0], mesh_rpy[1] + self.wheel_phi[2 + k], theta_drawbar,
                'package://tractor_description/mesh/DR_Wheel.obj', current_stamp
            ))

            # Trailer Chassis
            tl_x, tl_y = self.to_map_coordinate(tl_cad[0], tl_cad[1], p_axle[0], p_axle[1], theta_trailer)
            marker_array.markers.append(self.create_mesh_marker(
                tl_x, tl_y, map_z, mesh_rpy[0], mesh_rpy[1], theta_trailer,
                'package://tractor_description/mesh/Trailerl.obj', current_stamp
            ))

            # Trailer Left Wheel
            tl_wl_x, tl_wl_y = self.to_map_coordinate(0.0, self.tl_tw / 2.0, p_axle[0], p_axle[1], theta_trailer)
            tl_mx, tl_my, tl_mz = self.wheel_mesh_position(tl_wl_x, tl_wl_y, theta_trailer, self.wheel_phi[2 + k], map_z, wheel_centers['tl'])
            marker_array.markers.append(self.create_mesh_marker(
                tl_mx, tl_my, tl_mz, mesh_rpy[0], mesh_rpy[1] + self.wheel_phi[2 + k], theta_trailer,
                'package://tractor_description/mesh/TL_Wheel.obj', current_stamp
            ))

            # Trailer Right Wheel
            tr_wl_x, tr_wl_y = self.to_map_coordinate(0.0, -self.tl_tw / 2.0, p_axle[0], p_axle[1], theta_trailer)
            tr_mx, tr_my, tr_mz = self.wheel_mesh_position(tr_wl_x, tr_wl_y, theta_trailer, self.wheel_phi[2 + k], map_z, wheel_centers['tr'])
            marker_array.markers.append(self.create_mesh_marker(
                tr_mx, tr_my, tr_mz, mesh_rpy[0], mesh_rpy[1] + self.wheel_phi[2 + k], theta_trailer,
                'package://tractor_description/mesh/TR_Wheel.obj', current_stamp
            ))

        # 5. Publish MarkerArray Topic
        self.pub_markers.publish(marker_array)

    def convert_latlon_to_mgrs(self, lat: float, lon: float, precision: int = 5) -> str:
        """
        Convert Latitude and Longitude to an MGRS coordinate string.
        """
        import mgrs
        m = mgrs.MGRS()
        
        # Convert to MGRS
        mgrs_result = m.toMGRS(lat, lon, MGRSPrecision=precision)
        
        # Decode byte string to normal string if needed
        if isinstance(mgrs_result, bytes):
            return mgrs_result.decode('utf-8')
        
        return mgrs_result

    def destroy_node(self):
        self.http_client.close()
        super().destroy_node()

def main(args=None):
    rclpy.init(args=args)
    node = AGVPoseDisplayNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
